<?php

do_action('vehica/layouts/template/prepareCss');

get_header();

do_action('vehica/layouts/single/template');

get_footer();