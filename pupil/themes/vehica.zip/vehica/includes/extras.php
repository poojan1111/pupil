<?php

/**
 * @param mixed $embed
 * @return mixed
 */
function vehica_embed($embed)
{
    return $embed;
}