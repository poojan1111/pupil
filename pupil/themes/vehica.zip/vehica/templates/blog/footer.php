    </div>
    <div class="vehica-footer">
        <div class="vehica-footer__inner">
            <?php esc_html_e('Copyright ©', 'vehica'); ?>
            <?php echo esc_html(date('Y')); ?> <?php echo esc_html(get_bloginfo('name')); ?>
        </div>
    </div>
</div>