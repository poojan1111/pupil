<?php
/* @var \Vehica\Widgets\General\ContactFormGeneralWidget $vehicaCurrentWidget */
global $vehicaCurrentWidget;
?>
<div class="vehica-contact-form">
    <?php $vehicaCurrentWidget->displayForm(); ?>
</div>
