<?php
/* @var \Vehica\Widgets\General\RegisterGeneralWidget $vehicaCurrentWidget */
global $vehicaCurrentWidget;
?>
<div class="vehica-app vehica-panel">
    <div class="vehica-register">
        <div class="vehica-register__inner">
            <?php get_template_part('templates/general/login/register_form'); ?>
        </div>
    </div>
</div>