<div class="vehica-swiper-slide vehica-carousel-v1__slide">
    <?php get_template_part('templates/card/car/card_v1'); ?>
</div>