<?php

namespace Vehica\Core\Page;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Class Page
 * @package Vehica\Core\Page
 */
class Page
{
    const POST_TYPE = 'page';
    const SINGLE = 'single';
    CONST ARCHIVE = 'archive';
}